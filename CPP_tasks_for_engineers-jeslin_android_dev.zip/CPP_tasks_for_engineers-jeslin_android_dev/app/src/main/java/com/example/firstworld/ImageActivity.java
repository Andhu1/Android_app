package com.example.firstworld;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ArrayAdapter;
import android.widget.AdapterView;
import androidx.appcompat.widget.SwitchCompat;
import android.widget.SeekBar;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;



public class ImageActivity extends AppCompatActivity {
    Button submitButton;
    EditText screenNameText;
    RadioGroup radioGroupFormat;
    RadioButton radioButton;
    CheckBox checkBoxConnectivity;
    CheckBox checkBoxMediaAudio;
    CheckBox checkBoxTelephony;
    CheckBox checkBoxVehicleStatus;
    CheckBox checkBoxTimeDate;
    CheckBox checkBoxNavigation;
    SwitchCompat bluetoothSwitch;
    SwitchCompat NightMode;
    SwitchCompat BatterySaver;
    SwitchCompat DoNotDisturb;
    Spinner mapViewSpinner;
    SeekBar seekBarBrightness;
    TextView brightnessLevel;
    ProgressBar submitProgressBar;
    TextView textViewSummary;

    private String summary;
    private String format;
    private String statusBar;
    private String switchStatus;
    private String spinnerMapViewType;
    private String brightnessLevelStr;
    private  boolean progressStatus;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_image);

        submitButton = findViewById(R.id.submitButton);
        textViewSummary = findViewById(R.id.submitSummary);
        screenNameText = findViewById(R.id.screenName);
        radioGroupFormat = findViewById(R.id.formatGroup);
        checkBoxConnectivity = findViewById(R.id.Connectivity);
        checkBoxMediaAudio = findViewById(R.id.MediaAudio);
        checkBoxTelephony = findViewById(R.id.Telephony);
        checkBoxVehicleStatus = findViewById(R.id.VehicleStatus);
        checkBoxTimeDate = findViewById(R.id.TimeDate);
        checkBoxNavigation = findViewById(R.id.Navigation);
        bluetoothSwitch = findViewById(R.id.bluetoothSwitch);
        NightMode = findViewById(R.id.NightMode);
        BatterySaver = findViewById(R.id.BatterySaver);
        DoNotDisturb = findViewById(R.id.DoNotDisturb);
        mapViewSpinner = findViewById(R.id.mapViewType);
        seekBarBrightness = findViewById(R.id.brightnessControl);
        brightnessLevel = findViewById(R.id.brightnessLevel);
        submitProgressBar = findViewById(R.id.progressBar);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,
                R.array.map_view_type,
                android.R.layout.simple_spinner_item);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mapViewSpinner.setAdapter(adapter);

        mapViewSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                spinnerMapViewType = "\n Map view type Selected: " + parent.getItemAtPosition(position).toString().trim();
                Toast.makeText(getApplicationContext(), spinnerMapViewType, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                spinnerMapViewType = "\n Map view type Selected: " + "none";
            }
        });

        seekBarBrightness.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int level = progress + 1;
                brightnessLevelStr = "\nBrightness Level: " + level;
                brightnessLevel.setText("Brightness Level: " + level);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                Toast.makeText(getApplicationContext(), "adjusting brightness...", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });

        radioGroupFormat.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                radioButton = group.findViewById(checkedId);
                format = "\nformat choosed : " + radioButton.getText().toString().trim();
            }
        });


        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String screenName = screenNameText.getText().toString().trim();
                if (screenName.isEmpty()) {
                    Toast.makeText(ImageActivity.this, "Please enter a name", Toast.LENGTH_SHORT).show();
                    return;
                }

                fetchStatusBar();
                fetchSwitchStatus();

                summary = "Name entered: " + screenName + format + "\nStatus bar choosed : " + statusBar + "\nswitched status : " + switchStatus
                            + spinnerMapViewType + brightnessLevelStr;
                textViewSummary.setText(summary);
            }
        });






    }



    private void fetchStatusBar(){

        if (checkBoxConnectivity.isChecked()) {
            statusBar += "Connectivity enabled, ";
        } else {
            statusBar += "Connectivity disabled, ";
        }

        if (checkBoxMediaAudio.isChecked()) {
            statusBar += "Media Audio enabled, ";
        } else {
            statusBar += "Media Audio disabled, ";
        }

        if (checkBoxTelephony.isChecked()) {
            statusBar += "Telephony enabled, ";
        } else {
            statusBar += "Telephony disabled, ";
        }

        if (checkBoxVehicleStatus.isChecked()) {
            statusBar += "Vehicle Status enabled, ";
        } else {
            statusBar += "Vehicle Status disabled, ";
        }

        if (checkBoxTimeDate.isChecked()) {
            statusBar += "Time & Date enabled, ";
        } else {
            statusBar += "Time & Date disabled, ";
        }

        if (checkBoxNavigation.isChecked()) {
            statusBar += "Navigation enabled";
        } else {
            statusBar += "Navigation disabled";
        }
    }

    private void fetchSwitchStatus() {

        if (bluetoothSwitch.isChecked()) {
            switchStatus += "Bluetooth ON, ";
        } else {
            switchStatus += "Bluetooth OFF, ";
        }

        if (NightMode.isChecked()) {
            switchStatus += "Night Mode ON, ";
        } else {
            switchStatus += "Night Mode OFF, ";
        }

        if (BatterySaver.isChecked()) {
            switchStatus += "Battery Saver ON, ";
        } else {
            switchStatus += "Battery Saver OFF, ";
        }

        if (DoNotDisturb.isChecked()) {
            switchStatus += "Do Not Disturb ON";
        } else {
            switchStatus += "Do Not Disturb OFF";
        }
    }
}