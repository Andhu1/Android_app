package com.example.firstworld;

import android.content.Intent;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.view.View;
import android.widget.Button;

import android.util.Log;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.Spinner;
/**
 *
 */

public class MainActivity extends AppCompatActivity {
    EditText userName, userPassword;
    private final String myName = "Jeslin";
    private  final String myPassword = "Sweng@004";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        Button clickMeButton = findViewById(R.id.click_me_button);
        userName = findViewById(R.id.name_edit_text);
        userPassword = findViewById(R.id.password_edit_text);



        clickMeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nameString = userName.getText().toString().trim();
                String passwordString = userPassword.getText().toString().trim();

                if(true) {
                    Intent intent = new Intent(MainActivity.this, ImageActivity.class);
                    startActivity(intent);
                }
                else{
                    Toast.makeText(MainActivity.this, "invalid password or username", Toast.LENGTH_SHORT).show();
                }
            }
        });



    }
    @Override
    protected  void onStart(){
        super.onStart();
        Log.d("MainActivity", "onStart");
    }

    @Override
    protected void onResume(){
        super.onResume();
        Log.d("MainActivity", "onResume");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d("MainActivity", "onPause");
    }

    @Override
    protected void onStop() {
        super.onStop();
        // Your code for onStop() goes here.
        // For example, unregister listeners or release resources
        // that should not be held while the activity is not visible.
//        Log.d(TAG, "onStop() called");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
//        Log.d(TAG, "onDestroy() called");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
//        Log.d(TAG, "onRestart() called");
    }
}